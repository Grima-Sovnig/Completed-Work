/*
    Title: Program 1 Donut Quiz
    Author: Gabriel Snider
    Date: 1-30-2020
    Purpose: A questionnaire to decide what donut someone is.
*/
#include <iostream>
using namespace std;

int main()
{
    /* Here is where I will declare all the variables that I will use in this program. 
    I start with the integer variables for the donut types, and the highest scoring donut.
    Then I make the character variables for the questions responses, and the input for play again loop. */
    /* Integers */ /* These variables hold the current score for each donut that will be printed at the end results. */
    int glazedD;
    int pbjD;
    int creamD;
    int bluecakeD;
    int gtwistD;
    int ChocSD;
    /* Character */ /* These characters are for the input for each question, they store the players answers. */
    char question1;
    char question2;
    char question3;
    char question4;
    char question5;
    char question6;
    char question7;
    char question8;
    char question9;
    char question10; 
    // These variables will be used for the loop that allows the program to be run more than once.
    bool runagain = true;
    char playAgain;
    
    while (runagain)
    {
    glazedD=0;
    pbjD=0;
    creamD=0;
    bluecakeD=0;
    gtwistD=0;
    ChocSD=0;

    
 
    /* Here we start the program with a do while loop so the user will be able to play again if they so choose. */
    

    cout << "--------------------------------------" << endl;
    cout << "*****WHAT TYPE OF DONUT ARE YOU?*****" << endl;
    cout << "--------------------------------------" << endl;

    cout << "----------------------------------------------------" << endl;
    cout << "***Answer these questions to get your Donut Type!***" << endl;
    cout << "----------------------------------------------------" << endl;
    

    /* QUESTIONS AND RESPONSE */
    /* Underneath each question is a cin statement that takes the users input. The input is then passed through a if else sequence that adds to the respective donut. */
    
    cout << "Q1: If You Are Playing League of Legends What Role Do You Pick?" << endl;
    cout << "a. Top Lane" << endl;
    cout << "b. Jungle" << endl;
    cout << "c. Mid Lane" << endl;
    cout << "d. Bot Lane" << endl;
    cout << "e. Support" << endl;
    cout << "f. What is League of Legends?" << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question1;


    if (question1 =='a')
    { 
        glazedD=glazedD+1;
    }  
    else if (question1 =='b')
    {
        pbjD=pbjD+1;
    }
    else if  (question1 =='c')
    {
        creamD=creamD+1;
    }
    else if (question1 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question1 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question1 =='f')
    {
        ChocSD=ChocSD+1;
    }
    
    
    cout << "Q2: What Type of Music Do You Prefer?" << endl;
    cout << "a. Pop" << endl;
    cout << "b. Rap" << endl;
    cout << "c. Jazz" << endl;
    cout << "d. Heavy Metal" << endl;
    cout << "e. Rock" << endl;
    cout << "f. Classical" << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question2;

    if (question2 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question2 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question2 =='c')
    {
        creamD=creamD+1;
    }
    else if (question2 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question2 =='e')
    {
        gtwistD=gtwistD+1;
    } 
    else if (question2 =='f')
    {
        ChocSD=ChocSD+1;
    }


    cout << "Q3: You are looking at getting a computer do you....." << endl;
    cout << "a. Go to Best Buy" << endl;
    cout << "b. Look at Amazon" << endl;
    cout << "c. Ask a Friend" << endl;
    cout << "d. Build it Yourself" << endl;
    cout << "e. Buy a used School Computer" << endl;
    cout << "f. Buy from a System Builder" << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question3;

    if (question3 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question3 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question3 =='c')
    {
        creamD=creamD+1;
    }
    else if (question3 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question3 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question3 =='f')
    {
        ChocSD=ChocSD+1;
    }

    
    cout << "Q4: You are going out to eat, where do you go?" << endl;
    cout << "a. IHOP" << endl;
    cout << "b. Cracker Barrel" << endl;
    cout << "c. Red Robin" << endl;
    cout << "d. Buffalo Wild Wings" << endl;
    cout << "e. Waffle House" << endl;
    cout << "f. Five Guy's" << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question4;


    if (question4 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question4 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question4 =='c')
    {
        creamD=creamD+1;
    }
    else if (question4 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question4 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question4 =='f')
    {
        ChocSD=ChocSD+1;
    }
    
    
    cout << "Q5: Your group of friends wants to play a game, what game do you choose?" << endl;
    cout << "a. Counter Strike" << endl;
    cout << "b. Rocket League" << endl;
    cout << "c. Overwatch" << endl;
    cout << "d. League of Legends" << endl;
    cout << "e. Runescape" << endl;
    cout << "f. World of Warcraft" << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question5;

    
    if (question5 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question5 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question5 =='c')
    {
        creamD=creamD+1;
    }
    else if (question5 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question5 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question5 =='f')
    {
        ChocSD=ChocSD+1;
    }
   
    cout << "Q6: You are going to by a board game or card game, what do you buy?" << endl;
    cout << "a. Monopoly" << endl;
    cout << "b. Sorry!" << endl;
    cout << "c. Candy Land" << endl;
    cout << "d. Betrayal at House on the Hill" << endl;
    cout << "e. Dungeons and Dragons" << endl;
    cout << "f. UNO" << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question6;

    
    if (question6 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question6 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question6 =='c')
    {
        creamD=creamD+1;
    }
    else if (question6 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question6 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question6 =='f')
    {
        ChocSD=ChocSD+1;
    }
    
    cout << "Q7: What is your favorite candy bar?" << endl;
    cout << "a. Mars Bar" << endl;
    cout << "b. Hersheys" << endl;
    cout << "c. Three Musketeers" << endl;
    cout << "d. Zero" << endl;
    cout << "e. Milky Way" << endl;
    cout << "f. I don't like candy." << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question7;

    
    if (question7 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question7 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question7 =='c')
    {
        creamD=creamD+1;
    }
    else if (question7 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question7 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question7 =='f')
    {
        ChocSD=ChocSD+1;
    }
    

    cout << "Q8: You can see a once in a lifetime concert which do you choose?" << endl;
    cout << "a. The Rolling Stones" << endl;
    cout << "b. Gun n' Roses (Original Lineup)" << endl;
    cout << "c. Ariana Grande" << endl;
    cout << "d. Misfits (Full Original Lineup)" << endl;
    cout << "e. Pantera" << endl;
    cout << "f. Concerts aren't for me." << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;
    
    cin >> question8;

    
    if (question8 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question8 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question8 =='c')
    {
        creamD=creamD+1;
    }
    else if (question8 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question8 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question8 =='f')
    {
        ChocSD=ChocSD+1;
    }
    

    cout << "Q9: You can pick any place to go, where do you go?" << endl;
    cout << "a. Paris" << endl;
    cout << "b. Scotland" << endl;
    cout << "c. Hong Kong" << endl;
    cout << "d. Norway" << endl;
    cout << "e. California" << endl;
    cout << "f. I would rather stay home." << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question9;

    
    if (question9 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question9 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question9 =='c')
    {
        creamD=creamD+1;
    }
    else if (question9 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question9 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question9 =='f')
    {
        ChocSD=ChocSD+1;
    }
    

    cout << "Q10: You have made it this far in the quiz, are you ready to find out your donut type?" << endl;
    cout << "a. What was this quiz for again?" << endl;
    cout << "b. Ehh, kinda" << endl;
    cout << "c. IM READY" << endl;
    cout << "d. Yes, that is why I took this quiz in the first place." << endl;
    cout << "e. Nope, I have made it this far and don't care to know." << endl;
    cout << "f. I just hit f all the way through this quiz, hope I got a good flavor." << endl;
    cout << "To make a selection press a, b, c, d, e, or f. Then press ENTER:" << endl;

    cin >> question10;

    
    if (question10 =='a')
    {
        glazedD=glazedD+1;
    }
    else if (question10 =='b')
    {
        pbjD=pbjD+1;
    }
    else if (question10 =='c')
    {
        creamD=creamD+1;
    }
    else if (question10 =='d')
    {
        bluecakeD=bluecakeD+1;
    }
    else if (question10 =='e')
    {
        gtwistD=gtwistD+1;
    }
    else if (question10 =='f')
    {
        ChocSD=ChocSD+1;
    }
    
    /* Next, the program will print out the Results of each donut, the player's donut type will the be printed. */
    /* The program will then prompt the user for input on whether they want to play again */
     
    cout << "***************Results***************" << endl;
    cout << "*************************************" << endl;
    cout << "Glazed = " << glazedD << endl;
    cout << "Peanut Butter and Jelly = " << pbjD << endl;
    cout << "Cream Donut = " << creamD << endl;
    cout << "Blueberry Cake Donut = " << bluecakeD << endl;
    cout << "Glazed Twist Donut = " << gtwistD << endl;
    cout << "Chocolate Sprinkle = " << ChocSD << endl;
    cout << "**************************************" << endl;
    cout << "**************************************" << endl;

 // This if else loop compares all the values of the donuts and only prints the donut that has the most or if there isn't a dominant one it just says it can't tell.
    if (glazedD > pbjD && glazedD > creamD && glazedD > gtwistD && glazedD > bluecakeD && glazedD > ChocSD)
        cout << "You are a Glazed Donut" << endl;
    else if (pbjD > glazedD && pbjD > creamD && pbjD > bluecakeD && pbjD > gtwistD && pbjD > ChocSD)
        cout << "You are a Peanut Butter and Jelly Donut" << endl;
    else if (creamD > glazedD && creamD > pbjD && creamD > bluecakeD && creamD > gtwistD && creamD > ChocSD)
        cout << "You are a Cream Filled Donut" << endl;
    else if (bluecakeD > glazedD && bluecakeD > pbjD && bluecakeD > gtwistD && bluecakeD > creamD && bluecakeD > ChocSD)
        cout << "You are a Blueberry Cake Donut" << endl;
    else if (gtwistD > glazedD && gtwistD > pbjD && gtwistD > creamD && gtwistD > bluecakeD && gtwistD > ChocSD)
        cout << "You are a Glazed Twist Donut" << endl;
    else if (ChocSD > glazedD && ChocSD > pbjD && ChocSD > creamD && ChocSD > bluecakeD && ChocSD > gtwistD)
        cout << "You are a Chocolate Sprinkle Donut" << endl;
    else
        cout << "Sorry, I do not know what you are. I think you are confused." << endl;
    


    /* The next statements prompt the user to decide if they want to play again, and if y then the program restarts, if n the program stops. */

    cout << "Do you want to take the test again? Enter y/n."<< endl;

    cin >> playAgain;
        if(playAgain != 'y')
            runagain = false;
    }
    
     
    return 0;
} 