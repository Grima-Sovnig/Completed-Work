/*********************************************************
*    Title: SC-FI City Store Sales Program               *
*    Author: Gabriel Snider                              *
*    Date: Started on February 17, 2020                  *
*    Purpose: Creates a menu driven program that keeps   *
*    track of sales with tax and outputs them to a file. *
*********************************************************/


#include <iostream>
#include <iomanip>
#include <string>
#include <ctime>
#include <cstring>
#include <fstream>

using namespace std;

int main()   
{
    /* Variables */

    char salesMore;
    char deleteSales;
    string ITEM;
    double totalBoard;
    double totalComics;
    double totalCards;
    double totalMinis;
    double totalCB;
    int userChoice;
    double worth;
    double salesPrice;
    double salesAmount;
    const double TAX=.0975;
    double salesTotal;
    ifstream inFile;
    ofstream outputFile;
    time_t rawtime;


    /* Menu Base */
    while(userChoice != 4)  { //This line repeats the program until the user chooses 4.
    
        
        cout << "-----------------------------------------" << endl;
        cout << "Welcome to Sci-Fi City Sales Program" << endl << endl;
        cout << "Please select from the following menu items:" << endl;
        cout << "1. \t Enter Sales." << endl;
        cout << "2. \t Tally Sales for the Day." << endl;
        cout << "3. \t Delete Sales for the Day." << endl;
        cout << "4. \t End Program." << endl;
        cout << "Choose 1-4:  ";
        cin >> userChoice;

    /*Sales Input + Output to File */
    if (userChoice == 1) 
    {
        outputFile.open("sales.txt",ios::app); // opens the file to allow the data to be written to it.
        do // This repeats the entering of sales until the user decides they are done inputing the sales.
        {
        cout << "You chose to enter sales." << endl << endl;
        cout << "Choose the department from the following menu: " << endl;
        cout << "1. \t Board Games" << endl;
        cout << "2. \t Comics" << endl;
        cout << "3. \t Card Games"  << endl;
        cout << "4. \t Miniatures" << endl;
        cout << "5. \t Cardboard Cutouts" << endl;
        cin >> userChoice;
        // Out to file for Board Games
        while(userChoice > 5 || userChoice < 1) // Validation of user input.
        {
            cout << "Enter a Valid Number:" << endl;
            cin >> userChoice;
        }
        if (userChoice == 1) // This block is the same for each department only the item name changes.
        {
            outputFile << "Board Games" <<endl;
            cout << "What is the price of the item? " << endl;

            cin >> salesPrice;

            cout << "How many did they buy? " << endl;

            cin >> salesAmount;

            salesTotal = (salesPrice * salesAmount);
            salesTotal = salesTotal+(salesTotal*TAX);

            outputFile << setprecision(2) << fixed << salesTotal << endl;

            salesTotal= 0;

            cout << "Do you want to enter more sales? (y or n): ";

            cin >> salesMore;
        }

        // Out to file for Comics
        else if (userChoice == 2)
        {
            outputFile << "Comics" <<endl;

            cout << "What is the price of the item? " << endl;

            cin >> salesPrice;

            cout << "How many did they buy? " << endl;

            cin >> salesAmount;

            salesTotal = (salesPrice * salesAmount);
            salesTotal = salesTotal+(salesTotal*TAX);

            outputFile << setprecision(2) << fixed << salesTotal << endl;

            salesTotal= 0;

            cout << "Do you want to enter more sales? (y or n): ";

            cin >> salesMore;
        }

        // Out to file for Card Games
        else if (userChoice == 3)
        {    
            outputFile << "Card Games" <<endl;

            cout << "What is the price of the item? " << endl;

            cin >> salesPrice;

            cout << "How many did they buy? " << endl;

            cin >> salesAmount;

            salesTotal = (salesPrice * salesAmount);
            salesTotal = salesTotal+(salesTotal*TAX);

            outputFile << setprecision(2) << fixed << salesTotal << endl;

            salesTotal= 0;

            cout << "Do you want to enter more sales? (y or n): ";

            cin >> salesMore;
        }
        // Out to file for Miniatures
        else if (userChoice == 4)
        {
            outputFile << "Miniatures" <<endl;

            cout << "What is the price of the item? " << endl;

            cin >> salesPrice;

            cout << "How many did they buy? " << endl;

            cin >> salesAmount;

            salesTotal = (salesPrice * salesAmount);
            salesTotal = salesTotal+(salesTotal*TAX);

            outputFile << setprecision(2) << fixed << salesTotal << endl;

            salesTotal= 0;

            cout << "Do you want to enter more sales? (y or n): ";

            cin >> salesMore;
        }
        // Out to file for Cardboard Cutouts
        else if (userChoice == 5)
        {
            outputFile << "Cardboard Cutouts" <<endl;

            cout << "What is the price of the item? " << endl;

            cin >> salesPrice;

            cout << "How many did they buy? " << endl;

            cin >> salesAmount;

            salesTotal = (salesPrice * salesAmount);
            salesTotal = salesTotal+(salesTotal*TAX);

            outputFile << setprecision(2) << fixed << salesTotal << endl;

            salesTotal= 0;

            cout << "Do you want to enter more sales? (y or n): ";

            cin >> salesMore;
        }
        
        } while (salesMore == 'y');
        outputFile.close(); // closes the file
    }

    /* Total Sales */
    else if (userChoice == 2)
    {
        inFile.open("sales.txt");

        time(&rawtime);

        cout << "\n\n Total Sales ON " << ctime(&rawtime) << "\n";

        if (inFile.is_open())  // opening the file while checking for errors
        {
            while(!inFile.eof()) {
                getline(inFile, ITEM);

                if (ITEM == "Board Games"){
                    inFile >> worth;
                    totalBoard += worth;
                }
                else if (ITEM == "Comics"){
                    inFile >> worth;
                    totalComics += worth;
                }
                else if (ITEM == "Card Games"){
                    inFile >> worth;
                    totalCards += worth;
                }
                else if (ITEM == "Miniatures"){
                    inFile >> worth;
                    totalMinis += worth;
                }
                else if (ITEM == "Cardboard Cutouts"){
                    inFile >> worth;
                    totalCB += worth;
                }
            }
            inFile.ignore(); //pulls in the information from the file and correctly spaces it.
            inFile.close(); // closes the file
        }
        cout <<"------------------------------------------------------" << endl;
        cout <<"Cardboard Cutouts: " << setprecision(2) << fixed << totalCB << endl;
        cout <<"      Board Games: " << setprecision(2) << fixed << totalBoard << endl;
        cout <<"           Comics: " << setprecision(2) << fixed << totalComics << endl;
        cout <<"       Card Games: " << setprecision(2) << fixed << totalCards << endl;
        cout <<"       Miniatures: " << setprecision(2) << fixed << totalMinis << endl;
        cout <<"------------------------------------------------------" << endl;

        totalCB= 0;
        totalBoard=0;
        totalComics=0;
        totalCards=0;
        totalMinis=0;
    }

    /* File Deleteion of Sales.txt */
    else if (userChoice == 3)
    {
        cout << "Would you like to delete the sales file? (y or n) " << endl;
        cin >> deleteSales;

        if (deleteSales == 'y')
        {
            if (remove("sales.txt") != 0)
            
                cout << "Error deleteing file! \n\n";
                
            else
            {
                cout << "File Deleted. \n\n";
            }
        }
        else
        {
            cout << "You chose not to delete the file." << endl;
            
        }
    }
    /* End the Program if user decides */
    else if (userChoice == 4)
    {
        break;
    }

    else // Validation for main menu choices
    {
        cout << "Please enter a valid number." << endl;
    }
            
    }
    cout << "Have a good day!";
    return 0;

}