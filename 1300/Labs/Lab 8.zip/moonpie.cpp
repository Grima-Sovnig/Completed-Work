// Gabriel Snider

#include <iostream>
#include <vector>

using namespace std;

void enterStolenMoonPies(vector <int> &moonPieVector, int);
int totalMoonPies(vector <int> &moonPieVector, int daysStolen);
float averageMoonPies(int daysStolen, int totalStolen);
int highestMoonPies(vector <int> &moonPieVector, int daysStolen);
int lowestMoonPies(vector <int> &moonPieVector, int daysStolen);



int main()
{
    int daysStolen;
    cout <<"How many days did Jane steal moon pies?" << endl;
    cin >> daysStolen;
    vector <int> moonPieVector(daysStolen);

    enterStolenMoonPies(moonPieVector, daysStolen);

    int TotalStolen= totalMoonPies(moonPieVector, daysStolen);
    float AverageMoonPiesStolen= averageMoonPies(daysStolen, TotalStolen);
    int MostStolen= highestMoonPies(moonPieVector, daysStolen);
    int LeastStolen= lowestMoonPies(moonPieVector, daysStolen);

    cout <<"------------Results------------"<< endl;
    cout <<"TOTAL # MOON PIES STOLEN:  " << TotalStolen << endl;
    cout <<"AVERAGE # MOON PIES STOLEN PER DAY:  " << AverageMoonPiesStolen << endl;
    cout <<"MOST # MOON PIES STOLEN IN ONE DAY:  " << MostStolen << endl;
    cout <<"LEAST # MOON PIES STOLEN IN ONE DAY:  " << LeastStolen << endl; 



}

void enterStolenMoonPies(vector <int> &moonPieVector, int daysStolen)
{
    cout <<"Enter the number of moon pies stolen each day." << endl << endl;

    for(int x=0; x< moonPieVector.size(); x++)
    {
        cout << "Day  " << x+1 << ":  ";
        cin >> moonPieVector.at(x);
    }

}


int totalMoonPies(vector <int> &moonPieVector, int daysStolen)
{
    int totalStolen=0;
    for (int x = 0; x < daysStolen; x++)
    {
        totalStolen += moonPieVector.at(x);
    }


    return totalStolen;
}


float averageMoonPies(int daysStolen, int TotalStolen)
{
    float avg=0;
    avg = TotalStolen / static_cast<float>(daysStolen);

    return avg;

}


int highestMoonPies(vector <int> &moonPieVector, int daysStolen)
{
    int max = moonPieVector.at(0);

    for (int x = 0; x < daysStolen; x++)
    {
        if(moonPieVector.at(x) > max)
        {
            max = moonPieVector.at(x);
        }
    }

    return max;
}


int lowestMoonPies(vector <int> &moonPieVector, int daysStolen)
{
    int lowest = moonPieVector.at(0);

    for (int x = 0; x < daysStolen; x++ )
    {
        if(moonPieVector.at(x) < lowest)
        {
            lowest = moonPieVector.at(x);
        }

    }

    return lowest;
}