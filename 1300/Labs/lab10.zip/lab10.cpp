// Gabriel Snider Lab 10
#include <iostream>

using namespace std;

struct Player
{
    string name;
    string hometown;
    int age;
    int numGames;


};

int main()
{
    int numPlayers;
    int total;
    int largest=0;
    string largestP;
    int least=10000;
    string leastP;
    

    cout << "How many esports players are there at TTU who major in CSC?" << endl;
    cin >> numPlayers;
    Player Data[numPlayers];
    int *hours[numPlayers];

    cout << "Please enter in information about each player:" << endl << endl;

    for (int i=0; i < numPlayers; i++)
    {
        total = 0;
        cout << "Player " << i+1 <<":" << endl;
        cout << "\n\tNAME: ";
        cin.ignore();
        getline(cin, Data[i].name);
        cout << "\n\t HOMETOWN: ";
        cin.ignore();
        getline(cin, Data[i].hometown);
        cout << "\n\t AGE: ";
        cin >> Data[i].age;
        cout <<"\n\t HOW MANY GAMES DOES " << Data[i].name << " PLAY?\t";
        cin >> Data[i].numGames;
        hours[i]= new int [Data[i].numGames];

        for(int x=0; x < Data[i].numGames; x++)
        {
            cout << "\n Number of Hours " << Data[i].name << " PLAYED GAME " << x+1 << "\t";
            cin >> hours[i][x];
            total += hours[i][x];
            if (total > largest)
            {
                largest = total;
                largestP = Data[i].name;
            }
            if (total < least)
            {
                least = total;
                leastP = Data[i].name;
            }
        }
    }
    cout << "\n The player who played the most hours (" << largest << " hours) is " << largestP;
    cout << "\n The player who played the least hours (" << least << " hours) is " << leastP;

    for (int i=0; i<numPlayers; i++)
    {
        delete [] hours[i];
    }
    
    return 0;
}