#include "Elephant.h"
#include "Functions.cpp"



int main()
{
    char zooName[100];
    float foodElephant[SIZE];
    string nameElephants[SIZE];
    
    float foodTotal, foodAverage;
    int elephantIndex;

    
    cout <<"Hello! What is the name of your elephant zoo?" << endl;
    cin.getline(zooName,100);
    getElephantData(foodElephant, nameElephants);
    getStats(foodElephant, foodTotal,  foodAverage,  elephantIndex);


    cout <<"The total amount of food consumed by all 10 elephants at " << zooName << " is " << foodTotal << " pounds in one month." << endl << endl;
    cout <<"The average amount of food consumed at " << zooName << "is " << foodAverage << " pounds." << endl << endl << endl;
    cout <<"The elephant who eats the most (" << foodElephant[elephantIndex] << " pounds) is  " << nameElephants[elephantIndex] << " !!" << endl;

    






}