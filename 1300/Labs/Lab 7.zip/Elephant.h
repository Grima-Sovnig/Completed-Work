#ifndef _ELEPHANT_H
#define _ELEPHANT_H


#include <iostream>
#include <string>

using namespace std;
const int SIZE=10;
void getElephantData(float *foodElephant ,string *nameElephants);

void getStats(float *foodElephant ,float &foodTotal, float &foodAverage, int &elephantIndex);

#endif