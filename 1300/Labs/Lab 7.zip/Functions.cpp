#include "Elephant.h"

#ifndef _Functions_cpp
#define _Functions_cpp


void getElephantData(float *foodElephant, string *nameElephants)
{
    cout <<"Enter the name and how many pounds of food each elephant ate last month." << endl;
    for(int x=0; x<SIZE; x++)
    {
        cout <<"ELEPHANT " << x+1 << ":" << endl;
        cout <<"NAME - ";
        cin.ignore();
        getline(cin, nameElephants[x]);
        cout <<"FOOD AMOUNT - ";
        cin >> foodElephant[x];
    }


}

void getStats(float *foodElephant,float &foodTotal, float &foodAverage, int &elephantIndex)
{
    foodTotal= foodElephant[0]+foodElephant[1]+foodElephant[2]+foodElephant[3]+foodElephant[4]+foodElephant[5]+foodElephant[6]+foodElephant[7]+foodElephant[8]+foodElephant[9];
    foodAverage=(foodTotal)/10;
    elephantIndex=0;
    for(int x=0; x<SIZE; x++)
    {
        if(foodElephant[x] > elephantIndex)
        {
            elephantIndex = foodElephant[x];
        }
    }



}

#endif