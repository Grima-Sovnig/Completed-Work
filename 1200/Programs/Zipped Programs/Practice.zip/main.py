a=int(input("Enter Number"))
sumAll=a*2
print(sumAll)